const express = require("express")
const app = express();

app.listen(() => console.log("I'm Ready To Work..! 24H"));
app.get('/', (req, res) => {
  res.send(`
  <body>
  <center><h1>Bot 24H ON!</h1></center
  </body>`)
});


app.get('/', (req, res) => {
  res.send('Hello Express app!')
});

app.listen(3000, () => {
  console.log('server started');
});

const Discord = require('discord.js')
const client = new Discord.Client()
const ms = require("ms");
const gif = require("gif-search");




const prefix = "!!";//// برفكس البوت او البادئه

///كود الحاله
client.on("ready", () =>{
console.log(`${client.user.username} is streming `)
client.user.setActivity(`في خدمه عرب تيل`, {type:"!!help"})
})

/////كود الهيلب
client.on("message", async message =>{
 if(message.content === prefix + "help"){
 const embed = new Discord.MessageEmbed()
.setAuthor("اوامر البوت السرقات")
.setThumbnail(message.author.avatarURL())
.setColor("RANDOM")
.setDescription(`


\`${prefix}سيارة\`:
> -  عشان تسرق سيارة

\`${prefix}بقالة\`:
> -  عشان تسرق بقالة

\`${prefix}منزل\`:
> -  عشان تسرق منزل

\`${prefix}كازنو\`:
-لسرقة كازنو


\`${prefix}متحف\`:
-لسرقة المتحف

\`${prefix}بنك\`:

-لسرقة البنك المركزي

-لسرقة البنك فليكا

-لسرقة البنك بليتو


\`${prefix}اليخت\`:
-لسرقة اليخت


\`${prefix}المجوهرات\`:
-لسرقة المجوهرات

`)
.setFooter(``)///تحط رابط الصوره السيرفر او الخط اذا كان عندك
 message.channel.send(embed)
 } 

  
/////كود سرقات
if(message.content === prefix + "منزل"){
  const f = [
   "YF517P",
  "V7181M",
  "H710Y8",
  "D171N8",
  "S828Gm",
  "TRQV71",
    
  ]
  let fast = Math.floor(Math.random() * f.length)
  const e= [
   "لايوجد شي",
    "💵 - 100﷼",
    "💵 - 200﷼",
  "💵 - 300﷼",
  "💵 - 400﷼",
  "💵 -500﷼",
  "💵 - 600﷼",
  "💵 - 700﷼",
  "💵 - 800﷼",
  "💵 - 900﷼",
  "💵 - 1000﷼",
  "💵 - 2000﷼",
   "💵 - 3000﷼",
   "💵 - 7000﷼",
   "🔧 - فاتح اقفال",
  "🔧 - فاتح اقفال متقدم",
  "فارغ",
   " - راديو",
  "💳『・بطاقة محل الاسلحة・",
  "・لايوجد شي ・",
  
    
  ]
  let fastt = Math.floor(Math.random() * e.length)
  const embed = new Discord.MessageEmbed()
 .setAuthor(client.user.username, client.user.avatarURL())
 .setColor("random")
.setDescription(`\`\`\`${f[fast]}\`\`\``)
.setFooter(" عندك 15 ثانيه لفك الشفره")

  message.channel.send(embed)
 const filter = m => m.content.includes(f[fast]);
message.channel.awaitMessages(filter, {
          max: 1,
          time: 15000,
          errors: ['time'],
        }) 

.then((collected) => {
const embed = new Discord.MessageEmbed()
.setColor("YELLOW")
.setDescription(`\`\`\`${e[fastt]}\`\`\``)
.setFooter("✅ | تم السرقة بنجاح")
message.channel.send(embed)
})
.catch(() => {
const embed = new Discord.MessageEmbed()
.setColor("RED") 
.setDescription(`:x: | فشلت العمليه السرقة - لقد تم تحديد هويتك`)
.setFooter(`المجرم: ${message.author.tag}`)
message.channel.send(embed)
  
});    
}

if(message.content === prefix + "المجوهرات"){
  const w = [
  "IUO819",
  "BA1T61",
  "091GAB",
  "81Ja18",
  "9Q1p8n",
  "372702"

  ]
  let wea = Math.floor(Math.random() * w.length)
const v= [
   "لايوجد شي",
    "💵 - 100﷼",
    "💵 - 200﷼",
  "💵 - 300﷼",
  "💵 - 400﷼",
  "💵 -500﷼",
  "💵 - 600﷼",
  "💵 - 700﷼",
  "💵 - 800﷼",
  "💵 - 900﷼",
  "💵 - 1000﷼",
  "💵 - 2000﷼",
   "💵 - 3000﷼",
   "💵 - 7000﷼",
  "💳『・بطاقة متحف・",
    "لايوجد شي",
   "💎・ذهب ・",
  "💎・ساعة・",
   "💎・طقم ذهب・",
   "💎・مجوهرات・",
   "💎・ساعة ايفون・",
  "・ لايوجد شي・",
  "・ لايوجد شي・",
  
  

  ]
  let weaa = Math.floor(Math.random() * v.length)
  const embed = new Discord.MessageEmbed()
 .setAuthor(client.user.username, client.user.avatarURL())
 .setColor("random")
.setDescription(`\`\`\`${w[wea]}\`\`\``)
.setFooter("لديك 15 ثانيه لكتابة الشفره")
.setTimestamp()
  message.channel.send(embed)
 const filter = m => m.content.includes(w[wea]);
message.channel.awaitMessages(filter, {
          max: 1,
          time: 15000,
          errors: ['time'],
        }) 

.then((collected) => {
const embed = new Discord.MessageEmbed()
.setColor("YELLOW")
.setDescription(`\`\`\`${v[weaa]}\`\`\``)
.setFooter("✅ | تم السرقة بنجاح")
message.channel.send(embed)
})
.catch(() => {
const embed = new Discord.MessageEmbed()
.setColor("RED") 
.setDescription(`:x: | فشلت العمليه السرقة - لقد تم تحديد هويتك`)
.setFooter(`المجرم: ${message.author.tag}`)
message.channel.send(embed)
});    
}


if(message.content === prefix + "سيارة"){
const s = [
  "9201mn",
  "91amz1",
  "GVB128",
  "182nbm",
  "91Bza7",
  "283841",

  ]
  let saz = Math.floor(Math.random() * s.length)
const x = ["『・تم سرقه بنجاح・』",
   "تم سرقه بنجاح ",
           
  ]
  let sazz = Math.floor(Math.random() * x.length)
  const embed = new Discord.MessageEmbed()
 .setAuthor(client.user.username, client.user.avatarURL())
 .setColor("random")
.setDescription(`\`\`\`${s[saz]}\`\`\``)
.setFooter("عندك 15 ثانيه لفك الشفره")
.setTimestamp()
  message.channel.send(embed)
 const filter = m => m.content.includes(s[saz]);
message.channel.awaitMessages(filter, {
          max: 1,
          time: 15000,
          errors: ['time'],
        }) 

.then((collected) => {
const embed = new Discord.MessageEmbed()
.setColor("#05ff14")
.setDescription(`\`\`\`${x[sazz]}\`\`\``)
.setFooter("✅ | تم السرقة بنجاح ")
message.channel.send(embed)
})
.catch(() => {
const embed = new Discord.MessageEmbed()
.setColor("RED") 
.setDescription(`:x: | فشلت العمليه السرقه - لقد تم تحديد هويتك`)
.setFooter(`المجرم: ${message.author.tag} `)
message.channel.send(embed)
});    
}

if(message.content === prefix + "بقاله"){
const s = [
  "9201mn",
  "91amz1",
  "GVB128",
  "182nbm",
  "91Bza7",
  "283841",

  ]
  let saz = Math.floor(Math.random() * s.length)
const x = ["『・ لايوجد شي・』",
   "لايوجد شي",
    "💵 - 100﷼",
    "💵 - 200﷼",
  "💵 - 300﷼",
  "💵 - 400﷼",
  "💵 -500﷼",
  "💵 - 600﷼",
  "💵 - 700﷼",
  "💵 - 800﷼",
  "💵 - 900﷼",
  "💵 - 1000﷼",
  "💵 - 2000﷼",
   "💵 - 3000﷼",
   "💵 - 7000﷼",
   "🔧 - فاتح اقفال",
  "🔧 - فاتح اقفال متقدم",
  "🥤 - ببسي",
   " - راديو",
  "💳・بطاقة منزل・",
  "لايوجد شي ",
    "لايوجد شي",
  ]
  let sazz = Math.floor(Math.random() * x.length)
  const embed = new Discord.MessageEmbed()
 .setAuthor(client.user.username, client.user.avatarURL())
 .setColor("random")
.setDescription(`\`\`\`${s[saz]}\`\`\``)
.setFooter("عندك 15 ثانيه لفك الشفره")
.setTimestamp()
  message.channel.send(embed)
 const filter = m => m.content.includes(s[saz]);
message.channel.awaitMessages(filter, {
          max: 1,
          time: 15000,
          errors: ['time'],
        }) 

.then((collected) => {
const embed = new Discord.MessageEmbed()
.setColor("#05ff14")
.setDescription(`\`\`\`${x[sazz]}\`\`\``)
.setFooter("✅ | تم السرقة بنجاح ")
message.channel.send(embed)
})
.catch(() => {
const embed = new Discord.MessageEmbed()
.setColor("RED") 
.setDescription(`:x: | فشلت العمليه السرقه - لقد تم تحديد هويتك`)
.setFooter(`المجرم: ${message.author.tag} `)
message.channel.send(embed)
});    
}


if(message.content === prefix + "متحف"){
const s = [
  "9201mn",
  "91amz1",
  "GVB128",
  "182nbm",
  "91Bza7",
  "283841",

  ]
  let saz = Math.floor(Math.random() * s.length)
const x = ["『・ 10000・』",

    "💵 - 10000﷼",
    "💵 - 2000﷼",
  "💵 - 3000﷼",
  "💵 - 4000﷼",
  "💵 -5000﷼",
  "💵 - 6000﷼",
  "💵 - 7000﷼",
  "💵 - 8000﷼",
  "💵 - 9000﷼",
  "💵 - 1000﷼",
  "💵 - 2000﷼",
   "💵 - 3000﷼",
   "💵 - 7000﷼",
  "فارغ",
  "💳・بطاقة كازنو・",
  "💳・بطاقة بنك بوليتو",
  "💳『・بطاقة بنك مركزي・",

  ]
  let sazz = Math.floor(Math.random() * x.length)
  const embed = new Discord.MessageEmbed()
 .setAuthor(client.user.username, client.user.avatarURL())
 .setColor("random")
.setDescription(`\`\`\`${s[saz]}\`\`\``)
.setFooter("عندك 15 ثانيه لفك الشفره")
.setTimestamp()
  message.channel.send(embed)
 const filter = m => m.content.includes(s[saz]);
message.channel.awaitMessages(filter, {
          max: 1,
          time: 15000,
          errors: ['time'],
        }) 

.then((collected) => {
const embed = new Discord.MessageEmbed()
.setColor("#05ff14")
.setDescription(`\`\`\`${x[sazz]}\`\`\``)
.setFooter("✅ | تم السرقة بنجاح ")
message.channel.send(embed)
})
.catch(() => {
const embed = new Discord.MessageEmbed()
.setColor("RED") 
.setDescription(`:x: | فشلت العمليه السرقه - لقد تم تحديد هويتك`)
.setFooter(`المجرم: ${message.author.tag} `)
message.channel.send(embed)
});    
}


if(message.content === prefix + "كازنو"){
const s = [
  "9201mn",
  "91amz1",
  "GVB128",
  "182nbm",
  "91Bza7",
  "283841",

  ]
  let saz = Math.floor(Math.random() * s.length)
const x = ["『・ 40000・』",

    "💵 - 10000﷼",
    "💵 - 2000﷼",
  "💵 - 3000﷼",
  "💵 - 4000﷼",
  "💵 -5000﷼",
  "💵 - 6000﷼",
  "💵 - 7000﷼",
  "💵 - 8000﷼",
  "💵 - 9000﷼",
  "💵 - 1000﷼",
  "💵 - 2000﷼",
  "💎・ساعة ايفون・",
  "💳・بطاقة يخت・",,
  ]
  let sazz = Math.floor(Math.random() * x.length)
  const embed = new Discord.MessageEmbed()
 .setAuthor(client.user.username, client.user.avatarURL())
 .setColor("random")
.setDescription(`\`\`\`${s[saz]}\`\`\``)
.setFooter("عندك 15 ثانيه لفك الشفره")
.setTimestamp()
  message.channel.send(embed)
 const filter = m => m.content.includes(s[saz]);
message.channel.awaitMessages(filter, {
          max: 1,
          time: 15000,
          errors: ['time'],
        }) 

.then((collected) => {
const embed = new Discord.MessageEmbed()
.setColor("#05ff14")
.setDescription(`\`\`\`${x[sazz]}\`\`\``)
.setFooter("✅ | تم السرقة بنجاح ")
message.channel.send(embed)
})
.catch(() => {
const embed = new Discord.MessageEmbed()
.setColor("RED") 
.setDescription(`:x: | فشلت العمليه السرقه - لقد تم تحديد هويتك`)
.setFooter(`المجرم: ${message.author.tag} `)
message.channel.send(embed)
});    
}


if(message.content === prefix + "بنك"){
const s = [
  "9201mn",
  "91amz1",
  "GVB128",
  "182nbm",
  "91Bza7",
  "283841",

  ]
  let saz = Math.floor(Math.random() * s.length)
const x = ["『・ 10000 ・』",

    "💵 - 10000﷼",
    "💵 - 20000﷼",
  "💵 - 3000﷼",
  "💵 - 4000﷼",
  "💵 -5000﷼",
  "💵 - 6000﷼",
  "💵 - 7000﷼",
  "💵 - 8000﷼",
  "💵 - 9000﷼",
  "💵 - 1000﷼",
  "💵 - 2000﷼",
  "🔫 - pistol",
  "💳・بطاقة بنك بوليتو",
  "💳・بطاقة بنك المركزي",         

  ]
  let sazz = Math.floor(Math.random() * x.length)
  const embed = new Discord.MessageEmbed()
 .setAuthor(client.user.username, client.user.avatarURL())
 .setColor("random")
.setDescription(`\`\`\`${s[saz]}\`\`\``)
.setFooter("عندك 15 ثانيه لفك الشفره")
.setTimestamp()
  message.channel.send(embed)
 const filter = m => m.content.includes(s[saz]);
message.channel.awaitMessages(filter, {
          max: 1,
          time: 15000,
          errors: ['time'],
        }) 

.then((collected) => {
const embed = new Discord.MessageEmbed()
.setColor("#05ff14")
.setDescription(`\`\`\`${x[sazz]}\`\`\``)
.setFooter("✅ | تم السرقة بنجاح ")
message.channel.send(embed)
})
.catch(() => {
const embed = new Discord.MessageEmbed()
.setColor("RED") 
.setDescription(`:x: | فشلت العمليه السرقه - لقد تم تحديد هويتك`)
.setFooter(`المجرم: ${message.author.tag} `)
message.channel.send(embed)
});    
}


if(message.content === prefix + "اليخت"){
const s = [
  "9201mn",
  "91amz1",
  "GVB128",
  "182nbm",
  "91Bza7",
  "283841",

  ]
  let saz = Math.floor(Math.random() * s.length)
const x = ["『・ لايوجد شي・』",
   "لايوجد شي",
    "💵 - 10000﷼",
    "💵 - 20000﷼",
  "💵 - 3000﷼",
  "💵 - 4000﷼",
  "💵 -5000﷼",
  "💵 - 6000﷼",
  "💵 - 7000﷼",
  "💳・بطاقة بنك بوليتو",
  "💳・بطاقة بنك فليكا",
  "💎・ساعة ايفون・",

  ]
  let sazz = Math.floor(Math.random() * x.length)
  const embed = new Discord.MessageEmbed()
 .setAuthor(client.user.username, client.user.avatarURL())
 .setColor("random")
.setDescription(`\`\`\`${s[saz]}\`\`\``)
.setFooter("عندك 15 ثانيه لفك الشفره")
.setTimestamp()
  message.channel.send(embed)
 const filter = m => m.content.includes(s[saz]);
message.channel.awaitMessages(filter, {
          max: 1,
          time: 15000,
          errors: ['time'],
        }) 

.then((collected) => {
const embed = new Discord.MessageEmbed()
.setColor("#05ff14")
.setDescription(`\`\`\`${x[sazz]}\`\`\``)
.setFooter("✅ | تم السرقة بنجاح ")
message.channel.send(embed)
})
.catch(() => {
const embed = new Discord.MessageEmbed()
.setColor("RED") 
.setDescription(`:x: | فشلت العمليه السرقه - لقد تم تحديد هويتك`)
.setFooter(`المجرم: ${message.author.tag} `)
message.channel.send(embed)
});    
}
})

           
    
client.login(process.env.token);